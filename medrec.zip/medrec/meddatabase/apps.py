from django.apps import AppConfig


class MeddatabaseConfig(AppConfig):
    name = 'meddatabase'
